module project {
	requires java.desktop;
}